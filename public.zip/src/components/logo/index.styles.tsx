import tw from "tailwind-styled-components"


export const LogoImg = tw.img`mx-2`

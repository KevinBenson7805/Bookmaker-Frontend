import styled from "styled-components";

export const Container = styled.div`
  display: fixed;
  flex-direction: row;
`;


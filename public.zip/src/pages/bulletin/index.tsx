import Header from '@/components/header'


export default function Login() {
  return (
    <div>
      <Header selectedPage={"bulletin"}/>
    </div>
  )
}
